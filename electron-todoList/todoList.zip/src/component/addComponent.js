export default class AddComponent {
    constructor(content) {
      if (typeof content !== "undefined") {
        this.content = content;
        let ul = document.querySelector("ul");
        let li = document.createElement("li");
        li.innerHTML = `<input class="checkbox" type="checkbox"><label>${content}</label><span class="delete">x</span>`;
        ul.appendChild(li);
        document.querySelector(".doListText").value = null;
      }
    }
  }